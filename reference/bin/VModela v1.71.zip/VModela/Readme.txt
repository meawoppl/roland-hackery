****************************************************************
            Roland Virtual MODELA for Windows(R)
****************************************************************

WELCOME TO Virtual MODELA!

We recommend that you read through this document first to get a better understanding of Virtual MODELA. This "Readme" file provides some important information about installing and setting up Virtual MODELA.

The explanations here assume that you are already familiar with using in Windows.  For further information about using Windows, please refer the user's manual from Microsoft Corp.

If you are reading this file with Notepad, then at the Edit menu click "WordWrap" to select it and make the displayed file easier to read.


Table of Contents

1.  Summary 
2.  System requirements
3.  Installation
4.  Important notes


* "Windows(R)" and "Windows NT(R)" are registered trademark or trademark of Microsoft(R) Corporation in the United States and/or other countries.
* Pentium are registered trademarks of Intel Corporation in the United States.

Copyright (C) 1999-2008 Roland DG Corporation


========================================================
1.  Summary 
========================================================

Virtual MODELA is a program that accepts tool paths created using a cutting program from Roland DG Corp. (such as MODELA Player or 3D Engrave), and simulates the movement of the tool on the screen.
It runs under Windows.


========================================================
2.  System requirements
========================================================

- Microsoft(R) Windows(R) 95, Windows 98, Windows Me, Windows NT(R) 4.0, Windows 2000, Windows XP or Windows Vista (32-bit) operating system
- Internet Explorer 4.0 or higher
- The minimum required CPU for the operating system
- The minimum amount of required RAM for the operating system
- 5 Mbytes or more of free hard disk space for installation


========================================================
3.  Installation
========================================================

To install Virtual MODELA, please follow the procedures described below.  You cannot run Virtual MODELA directly from this installation disk.

Precaution
- If an old version is already installed, then delete the old version and install the new one.


--------------------
- Installing the program from CD-ROM
Follow the instructions on the setup menu on the CD-ROM to install and set up.


========================================================
4. Important notes
========================================================

To use Virtual MODELA, it is recommended that you set the monitor to use 32,000 colors or more (High Color).
The program runs regardless of the setting for the number of colors, but if the number of colors is set at fewer than 32,000 the display may be coarse, making it impossible to distinguish detailed areas of shapes. A setting for 32,000 colors or more (High Color) is especially recommended when you're using texture mapping.

========================================================

If you have further questions or problem, please contact to your local vendor or Roland sales center.

